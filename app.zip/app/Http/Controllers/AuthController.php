<?php
 
namespace App\Http\Controllers;
use App\Models\UsersModel;
use Illuminate\Http\Request;
use Illuminate\Foundation\Validation\ValidatesRequests;
use Session;
use Mail;
use  Redirect;
use Illuminate\Foundation\Auth\AuthenticatesUsers;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Crypt;
use Illuminate\Routing\Controller as BaseController;
class AuthController extends BaseController
{
    public function login(){
       return view('login');
    }

    public function authenticateUser(Request $request)
    {   
         
         
        $validatedData = $request->validate([
            'email' => 'required|email',
            'password' => 'required',
        ]);
        if (Auth::attempt(['email' => $request->input('email'), 'password' => $request->input('password')]))
        {
            $user = Auth::user(); 
           
            $data['user']=$user;
            $data['user_id']=$user->id; 
            $data['user_id']=$user->role_id; 
            Session::put('success','You are Login successfully!!');
            Session::put("logged_user",$data);
            return Redirect::to('dashboard');
            
        } else {
           
            return back()->with('error','your username or password are wrong.');
        }

    } 
} 