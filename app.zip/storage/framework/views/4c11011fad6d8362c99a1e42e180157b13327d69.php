<!doctype html>
<html lang="en">
    <head>
        <?php echo $__env->make('layout.partials.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </head>

    <body>
        <!-- Side Menu -->
        <?php echo $__env->make('layout.partials.sidebar-manu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <!-- Main Content Wrapper -->
        <div class="main-content d-flex flex-column">
         
            <?php echo $__env->yieldContent('content-wrapper'); ?>

            <!-- Footer -->
            <?php echo $__env->make('layout.partials.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>
         
        <?php echo $__env->make('layout.partials.footer-scripts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </body>
</html>
<?php /**PATH D:\raj\projects\praveen\akdsolutions\laravel\resources\views/layout/mainlayout.blade.php ENDPATH**/ ?>