<?php $__env->startSection('content-wrapper'); ?>
<!-- Start Login Area -->
<div class="login-area">
   <div class="d-table">
      <div class="d-table-cell">
         <div class="login-form">
            <div class="logo">
               <a href="/">
               <img src="<?php echo e(asset('assets/img/logo.png')); ?>" alt="image" style="width:40%">
               </a>
            </div>
            <h2>Welcome</h2>
            <?php if($errors->any()): ?>
            <div class="alert alert-danger">
               <ul>
                  <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <li><?php echo e($error); ?></li>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
               </ul>
            </div>
            <?php endif; ?>
            <form action="<?php echo e(url('authenticateUser')); ?>" method="post" id="login_form">
               <?php echo csrf_field(); ?>
               <div class="form-group">
                  <input type="text" class="form-control" name="email" placeholder="Email" required autocomplete="off">
                  <span class="label-title">
                  <i class='bx bx-user'></i>
                  </span>
               </div>
               <div class="form-group">
                  <input type="password" class="form-control" name="password" placeholder="Password" required  autocomplete="off">
                  <span class="label-title">
                  <i class='bx bx-lock'></i>
                  </span>
               </div>
               <button type="submit" class="login-btn">Login</button>
            </form>
         </div>
      </div>
   </div>
</div>
<!-- End Login Area -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.authlayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\raj\projects\praveen\akdsolutions\laravel\resources\views/login.blade.php ENDPATH**/ ?>