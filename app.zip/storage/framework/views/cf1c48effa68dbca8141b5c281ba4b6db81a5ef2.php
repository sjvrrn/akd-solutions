<!-- Vendors Min JS -->
<script src="<?php echo e(asset('assets/js/vendors.min.js')); ?>"></script> 
<script src="<?php echo e(asset('assets/js/jquery_validate.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/js/script.js')); ?>"></script>
<script src="<?php echo e(asset('assets/js/custom.js')); ?>"></script>
     
<?php /**PATH D:\raj\projects\praveen\akdsolutions\laravel\resources\views/layout/partials/footer-scripts.blade.php ENDPATH**/ ?>