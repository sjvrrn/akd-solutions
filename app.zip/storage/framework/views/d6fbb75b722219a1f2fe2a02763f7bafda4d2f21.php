<!-- Start Sidemenu Area -->
<nav class="navbar top-navbar navbar-expand">
    <div class="collapse navbar-collapse" id="navbarSupportContent">
        <div class="responsive-burger-menu d-block d-lg-none">
            <span class="top-bar"></span>
            <span class="middle-bar"></span>
            <span class="bottom-bar"></span>
        </div> 
        <ul class="navbar-nav right-nav align-items-center"> 
            <li class="nav-item dropdown profile-nav-item">
                <a href="#" class="nav-link dropdown-toggle" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                    <div class="menu-profile">
                        <span class="name">Hi! Admin</span>
                        <img src="<?php echo e(asset('assets/img/user1.jpg')); ?>" class="rounded-circle" alt="image">
                    </div>
                </a>

                <div class="dropdown-menu">
                    <div class="dropdown-header d-flex flex-column align-items-center">
                        <div class="figure mb-3">
                            <img src="<?php echo e(asset('assets/img/user1.jpg')); ?>" class="rounded-circle" alt="image">
                        </div>
                        <div class="info text-center">
                            <span class="name">Admin</span>
                            <p class="mb-3 email">admin@akdsolution.com</p>
                        </div>
                    </div>

                   
                    <div class="dropdown-footer">
                        <ul class="profile-nav">
                            <li class="nav-item">
                                <a href="<?php echo e(url('logout')); ?>" class="nav-link">
                                    <i class='bx bx-log-out'></i> <span>Logout</span>
                                </a>
                            </li>
                        </ul>
                    </div>
                </div>
            </li>
        </ul>
    </div>
</nav>
<div class="sidemenu-area">
    <div class="sidemenu-header">
        <a href="/" class="navbar-brand d-flex align-items-center">
            <img src="<?php echo e(asset('assets/img/small-logo.png')); ?>" alt="image" style="width:80px"> 
        </a>
        <span class="company_name">AKD SOLUTIONS</span>

        <div class="burger-menu d-none d-lg-block">
            <span class="top-bar"></span>
            <span class="middle-bar"></span>
            <span class="bottom-bar"></span>
        </div>

        <div class="responsive-burger-menu d-block d-lg-none">
            <span class="top-bar"></span>
            <span class="middle-bar"></span>
            <span class="bottom-bar"></span>
        </div>
    </div>

    <div class="sidemenu-body">
        <ul class="sidemenu-nav metisMenu h-100" id="sidemenu-nav" data-simplebar>
        <li class="nav-item <?php echo e(Request::is('dashboard') ? 'mm-active' : ''); ?>">
                <a href="/dashboard" class="nav-link">
                    <span class="icon"><i class='bx bx-home-circle'></i></span>
                    <span class="menu-title">Dashboard</span>
                </a>
            </li>

            <li class="nav-item <?php echo e(Request::is('manage-organization') ? 'mm-active' : ''); ?>">
                <a href="manage-organization" class="nav-link">
                    <span class="icon"><i class='bx bx-user'></i></span>
                    <span class="menu-title">Manage Organization</span>
                </a>
            </li>
        </ul>
    </div>
</div>
<!-- End Sidemenu Area -->
<?php /**PATH D:\raj\projects\praveen\akdsolutions\laravel\resources\views/layout/partials/sidebar-manu.blade.php ENDPATH**/ ?>