<!doctype html>
<html lang="en">
    <head>
        <?php echo $__env->make('layout.partials.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </head>

    <body>
        <!-- Main Content Layout -->
        <?php echo $__env->yieldContent('content-wrapper'); ?>

        <!-- Footer Scripts -->
        <?php echo $__env->make('layout.partials.footer-scripts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </body>
</html>
<?php /**PATH D:\raj\projects\praveen\akdsolutions\laravel\resources\views/layout/authlayout.blade.php ENDPATH**/ ?>