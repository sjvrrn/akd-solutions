<?php $__env->startSection('content-wrapper'); ?>
<!-- Breadcrumb Area -->
<div class="breadcrumb-area">
   <h1>Manage Organizations</h1>
   <ol class="breadcrumb">
      <li class="item">
         <a href="/">
         <i class='bx bx-home-alt'></i>
         </a>
      </li>
      <li class="item">Organizations</li>
   </ol>
</div>
 
<div class="card mb-30">
   <?php if(Session::get("success")): ?>
   <div class="alert alert-success" role="alert"><?php echo e(Session::get("success")); ?></div>
<?php Session::forget('success') ?>
   <?php endif; ?>
<div clas="col-12"><a href="<?php echo e(url('add-organization')); ?>" class="btn btn-md btn-danger mr-2 mt-2" " style="float: right;margin-bottom: 20px;">Add Organization</a></div>
<div class="card-body">
      <div class="table-responsive">
         <table class="table">
            <thead>
               <tr>
                  <th scope="col">#</th>
                  <th scope="col">Organization Name</th>
                  <th scope="col">Contact Person</th>
                  <th scope="col">Role </th>
                  <th scope="col">Email </th>
                  <th scope="col">Mobile </th> 
                  <th scope="col">Status </th> 
                  <th scope="col">Action </th>
               </tr>
            </thead>
            <tbody>
               <?php if(isset($organization_data[0])): ?>
               <?php $__currentLoopData = $organization_data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $organization): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
               <?php $status=($organization->status ==1)? "Active":"In Active";?>
               <tr>
                  <th scope="row">1</th>
                  <td><?php echo e($organization->organization_name ?? ''); ?></td>
                  <td><?php echo e($organization->contact_name ?? ''); ?></td>
                  <td><?php echo e($organization->role ?? ''); ?></td>
                  <td><?php echo e($organization->email ?? ''); ?></td>
                  <td><?php echo e($organization->mobile ?? ''); ?></td>
                  <td><?php echo e($status); ?></td>
                  <td><a href="<?php echo e(url('edit-organization')); ?>/<?php echo e($organization->organization_id); ?>">Edit</a></td>
               </tr>
               <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
               <?php else: ?>
               <tr>
                  <th colspan="8">No Organization found</th> 
               </tr>
              <?php endif; ?>
            </tbody>
         </table>
      </div>
   </div>
</div> 
<!-- End -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.mainlayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\raj\projects\praveen\akdsolutions\laravel\resources\views/organization/manage_organization.blade.php ENDPATH**/ ?>