<!-- Vendors Min JS -->
<script src="{{ asset('assets/js/vendors.min.js') }}"></script> 
<script src="{{ asset('assets/js/jquery_validate.min.js') }}"></script>
<script src="{{ asset('assets/js/script.js') }}"></script>
<script src="{{ asset('assets/js/custom.js') }}"></script>
     
